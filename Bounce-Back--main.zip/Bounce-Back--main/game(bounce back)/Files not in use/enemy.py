class Enemy:
    def __init__(self, name, health, attack_power, speed):
        self.name = name
        self.health = health
        self.attack_power = attack_power
        self.speed = speed

        #um i forgot