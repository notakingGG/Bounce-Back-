
import pygame
import random
import assets as a

pygame.init()

screen = pygame.display.set_mode((1000, 600))
clock = pygame.time.Clock()

title_font = pygame.font.SysFont(None, 80)
font = pygame.font.SysFont(None, 40)
small_font = pygame.font.SysFont(None, 28)

current_background = None

def play_background(sound):
    global current_background
    if current_background is sound:
        return
    if current_background is not None:
        current_background.stop()
    current_background = sound
    current_background.play(-1)

def stop_background():
    global current_background
    if current_background is not None:
        current_background.stop()
        current_background = None

MAP_X = 100
MAP_Y = 0
MAP_WIDTH = 800
MAP_HEIGHT = 600

MAPS = [
    ("Liyue", a.bg1to5),
    ("Grassy Landy", a.bg2),
    ("Spooky Scary Dungeon!!!", a.bg3),
    ("Crystal Cave!!!", a.bg4)
]

map_bg = [
    pygame.transform.scale(image, (MAP_WIDTH, MAP_HEIGHT))
    for name, image in MAPS
]

map_lobby_imgs = [
    pygame.transform.scale(image, (700, 420))
    for name, image in MAPS
]

map_sizes = [
    image.get_size()
    for name, image in MAPS
]

selected_map = 0
game_started = False
game_running = True
game_over = False

PLAYER_WIDTH = 70
PLAYER_HEIGHT = 50

BALL_FASTERNESS = 1.15
BALL_MAX_SPEED = 20

BALL_PRE_X = 6
BALL_PRE_Y = 4
BALL_SPAWN_DELAY = 5 * 60

DASH_CD = 120
PLAYER_SPEED = 5

POWERUP_SPAWN_DELAY = 480
POWERUP_DURATION = 300
POWERUP_SPEED_MULTIPLIER = 1.6
FIRE_SPEED_MULTIPLIER = 1.8

POWERUP_IMAGES = {
    "fire": pygame.transform.scale(a.pow_fire, (36, 36)),
    "speed": pygame.transform.scale(a.pow_speed, (36, 36)),
    "shield": pygame.transform.scale(a.pow_shield, (36, 36))
}

gravity = 0.7
jump_height = -20

map_value_things = [
    [
        (70, 305, 200, 50),
        (750, 305, 200, 50),
        (0, 480, 360, 50),
        (650, 480, 350, 50),
    ],
    [
        (0, 500, 1155, 113),
        (55, 150, 160, 51),
        (805, 150, 280, 51),
        (360, 290, 300, 53),
        (0, 392, 140, 116),
        (196, 444, 120, 54),
        (700, 444, 199, 54),
        (879, 392, 196, 116)
    ],
    [
        (0, 55, 160, 18),
        (0, 530, 385, 50),
        (525, 390, 140, 30),
        (850, 490, 385, 50),
        (850, 0, 385, 350),
        (0, 250, 385, 50),
        (300, 200, 385, 50)
    ],
    [
        (0, 0, 1160, 166),
        (60, 270, 60, 60),
        (516, 295, 221, 96),
        (878, 196, 85, 95),
        (216, 460, 148, 85),
        (0, 530, 510, 50),
        (708, 530, 422, 75)
    ]
]

spawns = [
    ((100, 312), (700, 312)),
    ((100, 152), (700, 152)),
    ((80, 500), (700, 500)),
    ((100, 530), (700, 530))
]

def conversion(map):
    source_width, source_height = map_sizes[map]
    converted = []
    for x, y, width, height in map_value_things[map]:
        scaled_x = MAP_X + round(x * MAP_WIDTH / source_width)
        scaled_y = MAP_Y + round(y * MAP_HEIGHT / source_height)
        scaled_width = round(width * MAP_WIDTH / source_width)
        scaled_height = round(height * MAP_HEIGHT / source_height)
        converted.append(
            pygame.Rect(
                scaled_x,
                scaled_y,
                scaled_width,
                scaled_height
            )
        )
    return converted

def physical_physics(player, dx, dy, vertical_speed, solids):
    player.x += round(dx)
    for solid in solids:
        if player.colliderect(solid):
            if dx > 0:
                player.right = solid.left
            elif dx < 0:
                player.left = solid.right
    player.y += round(dy)
    grounded = False
    for solid in solids:
        if player.colliderect(solid):
            if dy > 0:
                player.bottom = solid.top
                vertical_speed = 0
                grounded = True
            elif dy < 0:
                player.top = solid.bottom
                vertical_speed = 0
    floor_y = MAP_Y + MAP_HEIGHT
    if player.bottom >= floor_y:
        player.bottom = floor_y
        vertical_speed = 0
        grounded = True
    return vertical_speed, grounded

def speed_up_ball():
    global ball_horizontal_speed, ball_vertical_speed
    speed_limit = BALL_MAX_SPEED * (
        FIRE_SPEED_MULTIPLIER if fire_boost_active else 1
    )
    ball_horizontal_speed *= BALL_FASTERNESS
    ball_vertical_speed *= BALL_FASTERNESS
    ball_horizontal_speed = max(
        -speed_limit,
        min(ball_horizontal_speed, speed_limit)
    )
    ball_vertical_speed = max(
        -speed_limit,
        min(ball_vertical_speed, speed_limit)
    )

def reset_match():
    global game_over
    global player_one, player_two
    global ball, ball_horizontal_speed, ball_vertical_speed
    global ball_spawn_timer, ball_active
    global solid_rectangles
    global speed1_y, speed2_y
    global direction1, direction2
    global alive1, alive2
    global attacking1, attacking2
    global attack_frame1, attack_frame2
    global attack_tick1, attack_tick2
    global dashing1, dashing2
    global dash_frame1, dash_frame2
    global dash_tick1, dash_tick2
    global dash_direction1, dash_direction2
    global dash_cooldown1, dash_cooldown2
    global tick1, tick2, frame1, frame2
    global grounded1, grounded2
    global jumping1, jumping2, jump_frame1, jump_frame2
    global jump_tick1, jump_tick2
    global death_frame1, death_frame2, death_tick1, death_tick2
    global death_done1, death_done2
    global fire_charge1, fire_charge2
    global speed_timer1, speed_timer2
    global shield1, shield2
    global fire_boost_timer, fire_boost_active
    global powerup_rect, powerup_type, powerup_spawn_timer

    game_over = False
    solid_rectangles = conversion(selected_map)
    spawn1, spawn2 = spawns[selected_map]

    player_one = pygame.Rect(
        MAP_X + spawn1[0] - PLAYER_WIDTH // 2,
        spawn1[1] - PLAYER_HEIGHT,
        PLAYER_WIDTH,
        PLAYER_HEIGHT
    )

    player_two = pygame.Rect(
        MAP_X + spawn2[0] - PLAYER_WIDTH // 2,
        spawn2[1] - PLAYER_HEIGHT,
        PLAYER_WIDTH,
        PLAYER_HEIGHT
    )

    ball = a.ball.get_rect(center=(500, 300))
    ball_spawn_timer = BALL_SPAWN_DELAY
    ball_active = False

    ball_horizontal_speed = 0
    ball_vertical_speed = 0

    speed1_y = 0
    speed2_y = 0

    direction1 = 1
    direction2 = -1

    alive1 = True
    alive2 = True

    attacking1 = False
    attacking2 = False

    attack_frame1 = 0
    attack_frame2 = 0

    attack_tick1 = 0
    attack_tick2 = 0

    dashing1 = False
    dashing2 = False

    dash_frame1 = 0
    dash_frame2 = 0

    dash_tick1 = 0
    dash_tick2 = 0

    dash_direction1 = 1
    dash_direction2 = -1

    dash_cooldown1 = 0
    dash_cooldown2 = 0

    tick1 = 0
    tick2 = 0

    frame1 = 0
    frame2 = 0

    grounded1 = False
    grounded2 = False

    jumping1 = False
    jumping2 = False

    jump_frame1 = 0
    jump_frame2 = 0

    jump_tick1 = 0
    jump_tick2 = 0

    death_frame1 = 0
    death_frame2 = 0

    death_tick1 = 0
    death_tick2 = 0

    death_done1 = False
    death_done2 = False

    fire_charge1 = False
    fire_charge2 = False

    speed_timer1 = 0
    speed_timer2 = 0

    shield1 = False
    shield2 = False

    fire_boost_timer = 0
    fire_boost_active = False

    powerup_rect = None
    powerup_type = None
    powerup_spawn_timer = POWERUP_SPAWN_DELAY

while game_running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_running = False

        if event.type == pygame.KEYDOWN:
            if not game_started:
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    selected_map = (selected_map - 1) % len(MAPS)
                    a.select_sound.play()
                if event.key in (pygame.K_RIGHT, pygame.K_d):
                    selected_map = (selected_map + 1) % len(MAPS)
                    a.select_sound.play()
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    reset_match()
                    game_started = True
            elif game_over:
                if event.key == pygame.K_r:
                    reset_match()
                if event.key == pygame.K_ESCAPE:
                    game_started = False
                    game_over = False
            else:
                if event.key == pygame.K_ESCAPE:
                    game_started = False
                if event.key == pygame.K_e and alive1:
                    if not attacking1 and not dashing1:
                        attacking1 = True
                        attack_frame1 = 0
                        attack_tick1 = 0
                if event.key == pygame.K_RSHIFT and alive2:
                    if not attacking2 and not dashing2:
                        attacking2 = True
                        attack_frame2 = 0
                        attack_tick2 = 0
                if event.key == pygame.K_q and alive1:
                    if not attacking1 and not dashing1 and dash_cooldown1 == 0:
                        dashing1 = True
                        dash_frame1 = 0
                        dash_tick1 = 0
                        dash_direction1 = direction1
                        dash_cooldown1 = DASH_CD
                if event.key == pygame.K_RETURN and alive2:
                    if not attacking2 and not dashing2 and dash_cooldown2 == 0:
                        dashing2 = True
                        dash_frame2 = 0
                        dash_tick2 = 0
                        dash_direction2 = direction2
                        dash_cooldown2 = DASH_CD

    if not game_started:
        play_background(a.lobby_sound)
        screen.fill((15, 20, 40))
        title = title_font.render(
            "pick da map", True, (255, 255, 255)
        )
        screen.blit(
            title,
            (500 - title.get_width() // 2, 25)
        )
        screen.blit(map_lobby_imgs[selected_map], (150, 110))
        map_name = font.render(
            MAPS[selected_map][0],
            True,
            (255, 220, 100)
        )
        screen.blit(
            map_name,
            (500 - map_name.get_width() // 2, 540)
        )
        left_arrow = title_font.render(
            "<", True, (255, 255, 255)
        )
        right_arrow = title_font.render(
            ">", True, (255, 255, 255)
        )
        screen.blit(left_arrow, (65, 280))
        screen.blit(right_arrow, (880, 280))
        instructions = small_font.render(
            "left / right is chnage map :P    type enter to play: BOUNCE BACK!!!!!",
            True,
            (220, 220, 220)
        )
        screen.blit(
            instructions,
            (500 - instructions.get_width() // 2, 580)
        )
        pygame.display.flip()
        clock.tick(60)
        continue

    if game_over:
        screen.fill((15, 20, 40))
        if alive1:
            winner_text = title_font.render(
                "PLAYER 1 WINS!", True, (100, 255, 140)
            )
        else:
            winner_text = title_font.render(
                "PLAYER 2 WINS!", True, (100, 200, 255)
            )
        restart_text = font.render(
            "Press R to restart this map",
            True,
            (255, 255, 255)
        )
        lobby_text = font.render(
            "Press ESC to return to map selection",
            True,
            (220, 220, 220)
        )
        screen.blit(
            winner_text,
            (500 - winner_text.get_width() // 2, 190)
        )
        screen.blit(
            restart_text,
            (500 - restart_text.get_width() // 2, 310)
        )
        screen.blit(
            lobby_text,
            (500 - lobby_text.get_width() // 2, 365)
        )
        pygame.display.flip()
        clock.tick(60)
        continue

    play_background(a.game_sound)

    if not ball_active:
        ball_spawn_timer -= 1
        if ball_spawn_timer <= 0:
            ball_active = True
            ball_horizontal_speed = BALL_PRE_X
            ball_vertical_speed = BALL_PRE_Y

    key_state = pygame.key.get_pressed()

    if speed_timer1 > 0:
        speed_timer1 -= 1
    if speed_timer2 > 0:
        speed_timer2 -= 1

    if fire_boost_timer > 0:
        fire_boost_timer -= 1
        if fire_boost_timer == 0 and fire_boost_active:
            ball_horizontal_speed /= FIRE_SPEED_MULTIPLIER
            ball_vertical_speed /= FIRE_SPEED_MULTIPLIER
            ball_horizontal_speed = max(
                -BALL_MAX_SPEED,
                min(ball_horizontal_speed, BALL_MAX_SPEED)
            )
            ball_vertical_speed = max(
                -BALL_MAX_SPEED,
                min(ball_vertical_speed, BALL_MAX_SPEED)
            )
            fire_boost_active = False

    if dash_cooldown1 > 0:
        dash_cooldown1 -= 1
    if dash_cooldown2 > 0:
        dash_cooldown2 -= 1

    dx1 = 0
    dx2 = 0

    if alive1 and not attacking1 and not dashing1:
        if key_state[pygame.K_a]:
            dx1 -= PLAYER_SPEED * (
                POWERUP_SPEED_MULTIPLIER if speed_timer1 > 0 else 1
            )
            direction1 = -1
        if key_state[pygame.K_d]:
            dx1 += PLAYER_SPEED * (
                POWERUP_SPEED_MULTIPLIER if speed_timer1 > 0 else 1
            )
            direction1 = 1
        if key_state[pygame.K_w] and grounded1:
            speed1_y = jump_height
            grounded1 = False
            jumping1 = True
            jump_frame1 = 0
            jump_tick1 = 0
            a.jump_sound.play()

    if alive2 and not attacking2 and not dashing2:
        if key_state[pygame.K_LEFT]:
            dx2 -= PLAYER_SPEED * (
                POWERUP_SPEED_MULTIPLIER if speed_timer2 > 0 else 1
            )
            direction2 = -1
        if key_state[pygame.K_RIGHT]:
            dx2 += PLAYER_SPEED * (
                POWERUP_SPEED_MULTIPLIER if speed_timer2 > 0 else 1
            )
            direction2 = 1
        if key_state[pygame.K_UP] and grounded2:
            speed2_y = jump_height
            grounded2 = False
            jumping2 = True
            jump_frame2 = 0
            jump_tick2 = 0
            a.jump_sound.play()

    if alive1:
        speed1_y += gravity
        dash_dx1 = dash_direction1 * 12 if dashing1 else 0
        speed1_y, grounded1 = physical_physics(
            player_one,
            dx1 + dash_dx1,
            speed1_y,
            speed1_y,
            solid_rectangles
        )

    if alive2:
        speed2_y += gravity
        dash_dx2 = dash_direction2 * 12 if dashing2 else 0
        speed2_y, grounded2 = physical_physics(
            player_two,
            dx2 + dash_dx2,
            speed2_y,
            speed2_y,
            solid_rectangles
        )

    if alive1:
        if grounded1:
            jumping1 = False
            jump_frame1 = 0
            jump_tick1 = 0
        else:
            jumping1 = True
            jump_tick1 += 1
            if jump_tick1 % 3 == 0:
                jump_frame1 = min(jump_frame1 + 1, 11)

    if alive2:
        if grounded2:
            jumping2 = False
            jump_frame2 = 0
            jump_tick2 = 0
        else:
            jumping2 = True
            jump_tick2 += 1
            if jump_tick2 % 3 == 0:
                jump_frame2 = min(jump_frame2 + 1, 11)

    if dashing1:
        dash_tick1 += 1
        if dash_tick1 % 3 == 0:
            dash_frame1 += 1
        if dash_frame1 >= 10:
            dashing1 = False
            dash_frame1 = 0

    if dashing2:
        dash_tick2 += 1
        if dash_tick2 % 3 == 0:
            dash_frame2 += 1
        if dash_frame2 >= 10:
            dashing2 = False
            dash_frame2 = 0

    if alive1 and attacking1:
        attack_tick1 += 1
        if attack_tick1 % 3 == 0:
            attack_frame1 += 1
        if attack_frame1 >= 15:
            attacking1 = False
            attack_frame1 = 0
    elif alive1 and not dashing1:
        if dx1 != 0:
            tick1 += 1
            if tick1 % 2 == 0:
                frame1 = (frame1 + 1) % len(a.run)
        else:
            frame1 = 0
            tick1 = 0

    if alive2 and attacking2:
        attack_tick2 += 1
        if attack_tick2 % 3 == 0:
            attack_frame2 += 1
        if attack_frame2 >= 15:
            attacking2 = False
            attack_frame2 = 0
    elif alive2 and not dashing2:
        if dx2 != 0:
            tick2 += 1
            if tick2 % 2 == 0:
                frame2 = (frame2 + 1) % len(a.run2)
        else:
            frame2 = 0
            tick2 = 0

    player_one.clamp_ip(
        pygame.Rect(MAP_X, 0, MAP_WIDTH, MAP_HEIGHT)
    )
    player_two.clamp_ip(
        pygame.Rect(MAP_X, 0, MAP_WIDTH, MAP_HEIGHT)
    )

    if powerup_rect is None:
        powerup_spawn_timer -= 1
        if powerup_spawn_timer <= 0:
            powerup_type = random.choice(
                ("fire", "speed", "shield")
            )
            powerup_rect = POWERUP_IMAGES[powerup_type].get_rect(
                center=(
                    random.randint(MAP_X + 45, MAP_X + MAP_WIDTH - 45),
                    random.randint(MAP_Y + 55, MAP_Y + MAP_HEIGHT - 80)
                )
            )
            powerup_spawn_timer = POWERUP_SPAWN_DELAY

    if powerup_rect is not None:
        if alive1 and player_one.colliderect(powerup_rect):
            a.powerup_sound.play()
            if powerup_type == "fire":
                fire_charge1 = True
            elif powerup_type == "speed":
                speed_timer1 = POWERUP_DURATION
            elif powerup_type == "shield":
                shield1 = True
            powerup_rect = None
            powerup_type = None
        elif alive2 and player_two.colliderect(powerup_rect):
            a.powerup_sound.play()
            if powerup_type == "fire":
                fire_charge2 = True
            elif powerup_type == "speed":
                speed_timer2 = POWERUP_DURATION
            elif powerup_type == "shield":
                shield2 = True
            powerup_rect = None
            powerup_type = None

    if ball_active:
        ball.x += round(ball_horizontal_speed)
        ball.y += round(ball_vertical_speed)

        if ball.left <= MAP_X:
            ball.left = MAP_X
            ball_horizontal_speed = abs(ball_horizontal_speed)
        if ball.right >= MAP_X + MAP_WIDTH:
            ball.right = MAP_X + MAP_WIDTH
            ball_horizontal_speed = -abs(ball_horizontal_speed)
        if ball.top <= 0:
            ball.top = 0
            ball_vertical_speed = abs(ball_vertical_speed)
        if ball.bottom >= MAP_Y + MAP_HEIGHT:
            ball.bottom = MAP_Y + MAP_HEIGHT
            ball_vertical_speed = -abs(ball_vertical_speed)

        if alive1 and ball.colliderect(player_one):
            if attacking1:
                a.parry_sound.play()
                ball_horizontal_speed = (
                    abs(ball_horizontal_speed)
                    if ball.centerx >= player_one.centerx
                    else -abs(ball_horizontal_speed)
                )
                ball_vertical_speed = -1
                speed_up_ball()
                if fire_charge1:
                    ball_horizontal_speed *= FIRE_SPEED_MULTIPLIER
                    ball_vertical_speed *= FIRE_SPEED_MULTIPLIER
                    fire_boost_timer = POWERUP_DURATION
                    fire_boost_active = True
                    fire_charge1 = False
                ball.centerx = player_one.centerx + (
                    1 if ball_horizontal_speed > 0 else -1
                ) * (player_one.width // 2 + ball.width // 2 + 2)
            elif shield1:
                shield1 = False
                ball_horizontal_speed = (
                    abs(ball_horizontal_speed)
                    if ball.centerx >= player_one.centerx
                    else -abs(ball_horizontal_speed)
                )
                ball.centerx = player_one.centerx + (
                    1 if ball_horizontal_speed > 0 else -1
                ) * (player_one.width // 2 + ball.width // 2 + 2)
            else:
                alive1 = False

        if alive2 and ball.colliderect(player_two):
            if attacking2:
                a.parry_sound.play()
                ball_horizontal_speed = (
                    abs(ball_horizontal_speed)
                    if ball.centerx >= player_two.centerx
                    else -abs(ball_horizontal_speed)
                )
                ball_vertical_speed = -1
                speed_up_ball()
                if fire_charge2:
                    ball_horizontal_speed *= FIRE_SPEED_MULTIPLIER
                    ball_vertical_speed *= FIRE_SPEED_MULTIPLIER
                    fire_boost_timer = POWERUP_DURATION
                    fire_boost_active = True
                    fire_charge2 = False
                ball.centerx = player_two.centerx + (
                    1 if ball_horizontal_speed > 0 else -1
                ) * (player_two.width // 2 + ball.width // 2 + 2)
            elif shield2:
                shield2 = False
                ball_horizontal_speed = (
                    abs(ball_horizontal_speed)
                    if ball.centerx >= player_two.centerx
                    else -abs(ball_horizontal_speed)
                )
                ball.centerx = player_two.centerx + (
                    1 if ball_horizontal_speed > 0 else -1
                ) * (player_two.width // 2 + ball.width // 2 + 2)
            else:
                alive2 = False

    if not alive1 and not death_done1:
        death_tick1 += 1
        if death_tick1 % 4 == 0:
            death_frame1 += 1
            if death_frame1 >= 8:
                death_frame1 = 7
                death_done1 = True

    if not alive2 and not death_done2:
        death_tick2 += 1
        if death_tick2 % 4 == 0:
            death_frame2 += 1
            if death_frame2 >= 8:
                death_frame2 = 7
                death_done2 = True

    if (not alive1 and death_done1) or (not alive2 and death_done2):
        game_over = True

    screen.fill((0, 0, 0))
    screen.blit(map_bg[selected_map], (MAP_X, MAP_Y))

    if ball_active:
        screen.blit(a.ball, ball)

    if powerup_rect is not None:
        screen.blit(
            POWERUP_IMAGES[powerup_type],
            powerup_rect
        )

    if not ball_active:
        countdown_text = font.render(
            f"BALL IN: {(ball_spawn_timer + 59) // 60}",
            True,
            (255, 255, 255)
        )
        screen.blit(
            countdown_text,
            (500 - countdown_text.get_width() // 2, 250)
        )

    if alive1 or not death_done1:
        if not alive1:
            image1 = a.damaged[death_frame1]
        elif attacking1:
            image1 = a.attack[attack_frame1]
        elif dashing1:
            image1 = a.dash[dash_frame1]
        elif jumping1:
            image1 = a.jump[jump_frame1]
        else:
            image1 = a.run[frame1]
        if direction1 == -1:
            image1 = pygame.transform.flip(image1, True, False)
        image_rect1 = image1.get_rect()
        image_rect1.midbottom = player_one.midbottom
        screen.blit(image1, image_rect1)

    if alive2 or not death_done2:
        if not alive2:
            image2 = a.damaged2[death_frame2]
        elif attacking2:
            image2 = a.attack2[attack_frame2]
        elif dashing2:
            image2 = a.dash2[dash_frame2]
        elif jumping2:
            image2 = a.jump2[jump_frame2]
        else:
            image2 = a.run2[frame2]
        if direction2 == -1:
            image2 = pygame.transform.flip(image2, True, False)
        image_rect2 = image2.get_rect()
        image_rect2.midbottom = player_two.midbottom
        screen.blit(image2, image_rect2)

    cooldown1 = font.render(
        f"P1 Dash: {dash_cooldown1 / 60:.1f}s",
        True,
        (255, 255, 255)
    )
    cooldown2 = font.render(
        f"P2 Dash: {dash_cooldown2 / 60:.1f}s",
        True,
        (255, 255, 255)
    )

    screen.blit(cooldown1, (30, 30))
    screen.blit(cooldown2, (750, 30))

    status1 = []
    status2 = []

    if fire_charge1:
        status1.append("FIRE READY")
    if speed_timer1 > 0:
        status1.append(f"SPEED {speed_timer1 / 60:.1f}s")
    if shield1:
        status1.append("SHIELD")

    if fire_charge2:
        status2.append("FIRE READY")
    if speed_timer2 > 0:
        status2.append(f"SPEED {speed_timer2 / 60:.1f}s")
    if shield2:
        status2.append("SHIELD")

    if fire_boost_timer > 0:
        boost_text = small_font.render(
            f"raging deflect!: {fire_boost_timer / 60:.1f}s",
            True,
            (255, 100, 50)
        )
        screen.blit(
            boost_text,
            (500 - boost_text.get_width() // 2, 20)
        )

    if status1:
        status_text1 = small_font.render(
            " | ".join(status1),
            True,
            (255, 220, 100)
        )
        screen.blit(status_text1, (30, 65))

    if status2:
        status_text2 = small_font.render(
            " | ".join(status2),
            True,
            (255, 220, 100)
        )
        screen.blit(status_text2, (750, 65))

    if not alive1:
        dead1 = font.render(
            "p1 has died by a ball somehow", True, (255, 0, 0)
        )
        screen.blit(dead1, (50, 100))

    if not alive2:
        dead2 = font.render(
            "p2 has died by a ball somehow", True, (255, 0, 0)
        )
        screen.blit(dead2, (700, 100))

    pygame.display.flip()
    clock.tick(60)

stop_background()
pygame.quit()
