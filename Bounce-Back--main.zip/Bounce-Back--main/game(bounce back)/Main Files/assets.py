import pygame
pygame.init()
idle = []
attack = []
damaged = []
dash = []
run = []
jump = []
idle2 = []
attack2 = []
damaged2 = []
dash2 = []
run2 = []
jump2 = []
bg1to5 = pygame.image.load("Assets/Backgrounds/liyue_bg.png")
bg2 = pygame.image.load("Assets/Backgrounds/bg2.png")
bg3 = pygame.image.load("Assets/Backgrounds/bg3.png")
bg4 = pygame.image.load("Assets/Backgrounds/bg4.png")
stone_platform = pygame.image.load("Assets/platforms/stone_platform.png")
ball = pygame.image.load("Assets/balls/ball.png")
pow_fire = pygame.image.load("Assets/powerups/pow_fire.png")
pow_shield = pygame.image.load("Assets/powerups/pow_shield.png")
pow_speed = pygame.image.load("Assets/powerups/pow_speed.png")
game_sound = pygame.Sound("Assets/sounds/game.mp3")
jump_sound = pygame.mixer.Sound("Assets/sounds/jump.mp3")
lobby_sound = pygame.mixer.Sound("Assets/sounds/lobby.mp3")
powerup_sound = pygame.mixer.Sound("Assets/sounds/powerup.mp3")
select_sound = pygame.mixer.Sound("Assets/sounds/select.mp3")
parry_sound = pygame.mixer.Sound("Assets/sounds/sword.mp3")
bg1to5 = pygame.transform.scale(bg1to5, (1000, 600))
bg2 = pygame.transform.scale(bg2, (1000, 600))
bg3 = pygame.transform.scale(bg3, (1000, 600))
bg4 = pygame.transform.scale(bg4, (1000, 600))
stone_platform = pygame.transform.scale(stone_platform, (1000, 100))
pow_fire = pygame.transform.scale(pow_fire, (60, 80))
pow_shield = pygame.transform.scale(pow_shield, (60, 80))
pow_speed = pygame.transform.scale(pow_speed, (60, 80))
ball = pygame.transform.scale(ball, (60, 40))

for i in range(3):
    idle.append(pygame.image.load(f"Assets/Anims/Idle/tile00{i}.png"))

for i in range(15):
    if i >= 10:
        attack.append(pygame.image.load(f"Assets/Anims/Attack/tile0{i}.png"))
    else:
        attack.append(pygame.image.load(f"Assets/Anims/Attack/tile00{i}.png"))

for i in range(8):
    damaged.append(pygame.image.load(f"Assets/Anims/Damaged/tile00{i}.png"))

for i in range(10):
    if i >= 10:
        dash.append(pygame.image.load(f"Assets/Anims/Dash/tile0{i}.png"))
    else:
        dash.append(pygame.image.load(f"Assets/Anims/Dash/tile00{i}.png"))

for i in range(9):
    run.append(pygame.image.load(f"Assets/Anims/Run/tile00{i}.png"))

for i in range(12):
    if i >= 10:
        jump.append(pygame.image.load(f"Assets/Anims/Jump/tile0{i}.png"))
    else:
        jump.append(pygame.image.load(f"Assets/Anims/Jump/tile00{i}.png"))

for i in range(15):
    if i >= 10:
        attack2.append(pygame.image.load(f"Assets/Anims2/Attack/tile0{i}.png"))
    else:
        attack2.append(pygame.image.load(f"Assets/Anims2/Attack/tile00{i}.png"))

for i in range(8):
    damaged2.append(pygame.image.load(f"Assets/Anims2/Damaged/tile00{i}.png"))

for i in range(10):
    if i >= 10:
        dash2.append(pygame.image.load(f"Assets/Anims2/Dash/tile0{i}.png"))
    else:
        dash2.append(pygame.image.load(f"Assets/Anims2/Dash/tile00{i}.png"))

for i in range(9):
    run2.append(pygame.image.load(f"Assets/Anims2/Run/tile00{i}.png"))

for i in range(12):
    if i >= 10:
        jump2.append(pygame.image.load(f"Assets/Anims2/Jump/tile0{i}.png"))
    else:
        jump2.append(pygame.image.load(f"Assets/Anims2/Jump/tile00{i}.png"))

# (x, y, width, height)