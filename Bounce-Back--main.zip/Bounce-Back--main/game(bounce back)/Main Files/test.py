import pygame
import assets as a
pygame.init()
screen = pygame.display.set_mode((1000, 600))
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    screen.blit(a.bg4, (0, 0))
    pygame.draw.rect(screen, (255, 0, 0),  (760, 180, 70, 95))
    pygame.display.flip()

# was used for testing platform locations
